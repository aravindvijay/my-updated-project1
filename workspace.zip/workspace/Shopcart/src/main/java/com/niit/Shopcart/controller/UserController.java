package com.niit.Shopcart.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.niit.Shopcart.dao.CartDAO;
import com.niit.Shopcart.dao.CategoryDAO;
import com.niit.Shopcart.dao.UserDAO;
import com.niit.Shopcart.model.Cart;
import com.niit.Shopcart.model.Category;
import com.niit.Shopcart.model.User;

@Controller
public class UserController {

	@Autowired
	private Cart cart;
	
	@Autowired
	private CartDAO cartDAO;
	
	@Autowired
	Category category;
	
	@Autowired
	CategoryDAO categoryDAO;
	
	@Autowired
	private UserDAO userDAO;
	
	@Autowired
	private User user;
	
	@RequestMapping("/")
public ModelAndView onLoad(HttpSession session){
		
		ModelAndView mv=new ModelAndView("/index");
	    session.setAttribute("category",category);
	    session.setAttribute("categoryList", categoryDAO.list());
		return mv;
	}
//	public String getlanding(){
//		return "index";
//	}
	
  @RequestMapping("/about")
  public String getAbout(){
	  return "Aboutus";
  }
  
@RequestMapping("/contact")
public String getContact(){
	return "Contactus";
}



//@RequestMapping("/LoginHere")
//public String getLogin() {
//	return "Login";
//}
//@RequestMapping("/Signup")
//public ModelAndView signup(){
//		ModelAndView mv=new ModelAndView("/index");
//		mv.addObject("user",user);
//		mv.addObject("isUserClickedRegisterHere", "true");
//		return mv;
//}
//@RequestMapping("/check")
//public ModelAndView login(@RequestParam(value = "name") String name,
//						@RequestParam(value = "pass") String password){
//	ModelAndView mv;
//	boolean isValiduser = userDAO.isValiduser(name, password);
//	
//	if (isValiduser == true) {
//		mv = new ModelAndView("/loggedin");
//	} else {
//		
//		mv = new ModelAndView("/login");
//		mv.addObject("msg", "invalid User");
//	}
//	return mv;
	
@RequestMapping(value = "/login")
public String login(@RequestParam(value="error", required = false) String error, @RequestParam(value="logout",
        required = false) String logout, Model model) {
    if (error!=null) {
    	System.out.println("Error.....");
        model.addAttribute("error", "...Invalid username and password");
    }
    	
    if(logout!=null) {
    	System.out.println("Logout called.....");
        model.addAttribute("msg", "...You have been logged out");
    }

    return "login";
}

@RequestMapping(value = "/user")
public String userManagement() 
{
	System.out.println("USER CALLED.......");
	return "login";
}

@RequestMapping(value = "/admin")
public String adminManagement() 
{
	System.out.println("ADMIN CALLED.......");
	return "Adminhome";
}
	
}



