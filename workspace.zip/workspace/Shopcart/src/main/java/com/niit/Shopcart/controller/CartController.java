package com.niit.Shopcart.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.niit.Shopcart.dao.CartDAO;
import com.niit.Shopcart.dao.CategoryDAO;
import com.niit.Shopcart.dao.ProductDAO;
import com.niit.Shopcart.model.Cart;
import com.niit.Shopcart.model.Product;


@Controller
public class CartController {

	
	@Autowired
	Cart cart;
	@Autowired(required=true)
	private CartDAO cartDAO;
	
	@Autowired(required=true)
	private ProductDAO productDAO;
	
	@Autowired(required=true)
	private CategoryDAO categoryDAO;

	
	@RequestMapping(value = "/cart", method = RequestMethod.GET)
	public String myCart(Model model,HttpSession session) {
		
		model.addAttribute("cart", cart);
		String loggedInUserid=(String) session.getAttribute("loggedInUserId");
		System.out.println(loggedInUserid);
		model.addAttribute("cartList", cartDAO.list(loggedInUserid));
		//model.addAttribute("totalAmount", cartDAO.list(loggedInUserid));
		//model.addAttribute("cartList", this.cartDAO.list());
		model.addAttribute("totalAmount", cartDAO.getTotalAmount(loggedInUserid)); // Just to test, password user
		model.addAttribute("displayCart", "true");
		return "cart";
	}
	
	
	/*@RequestMapping(value = "/carts", method = RequestMethod.GET)
	public String listCarts(Model model) {
		model.addAttribute("cart", new Cart());
		model.addAttribute("cartList", this.cartDAO.list());
		return "cart";
	}*/
	
	
	//For add and update cart both
	@RequestMapping(value= "/cart/add/{id}", method = RequestMethod.GET)
	public String addToCart(@PathVariable("id") int id){
		
	
	 Product product =	 productDAO.get(id);
	 Cart cart = new Cart();
	 cart.setPrice(product.getPrice());
	 cart.setProductName(product.getName());
	 cart.setQuantity(1);
	 cart.setUser_Id("userID");
	// String loggedInUserid=(String) session.getAttribute("loggedInUserId");
	   //  id should keep session and use the same id
	 cart.setStatus('N');  // 
		cartDAO.saveOrUpdate(cart);
		//return "redirect:/views/index.jsp";
		return "redirect:/onLoad";
		
	}
	
	@RequestMapping("cart/delete/{id}")
    public String removeCart(@PathVariable("id") String id,ModelMap model) throws Exception{
		
       try {
		cartDAO.delete(id);
		model.addAttribute("message","Successfully removed");
	} catch (Exception e) {
		model.addAttribute("message",e.getMessage());
		e.printStackTrace();
	}
       //redirectAttrs.addFlashAttribute(arg0, arg1)
        return "redirect:/cart";
    }
 
   
    }



