package com.niit.Shopcart.handler;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.binding.message.MessageBuilder;
import org.springframework.binding.message.MessageContext;
import org.springframework.stereotype.Component;

import com.niit.Shopcart.dao.UserDAO;
import com.niit.Shopcart.model.User;

@Component
public class RegistrationHandler {
	@Autowired
	UserDAO userDAO;


	public User initFlow(){
		return new User();
	}

	public String validateDetails(User user,MessageContext messageContext){
		String status = "success";
		if(user.getUid().isEmpty()){
			messageContext.addMessage(new MessageBuilder().error().source(
					"uid").defaultText("UserId cannot be Empty").build());
			status = "failure";
		}
		if(user.getUname().isEmpty()){
			messageContext.addMessage(new MessageBuilder().error().source(
					"uname").defaultText("Name cannot be Empty").build());
			status = "failure";
		}
		if(user.getUpass().isEmpty()){
			messageContext.addMessage(new MessageBuilder().error().source(
					"upass").defaultText("Password cannot be Empty").build());
			status = "failure";
		}
	
		if(user.getUemail().isEmpty()){
			messageContext.addMessage(new MessageBuilder().error().source(
					"uemail").defaultText("Email cannot be Empty").build());
			status = "failure";
		}
		
		
		if(user.getUaddress().isEmpty()){
			messageContext.addMessage(new MessageBuilder().error().source(
					"uaddress").defaultText("Address cannot be Empty").build());
			status = "failure";
		}
		if(user.getUph().isEmpty()){
			messageContext.addMessage(new MessageBuilder().error().source(
					"uph").defaultText("Contact cannot be Empty").build());
			status = "failure";
		}
		return status;
	}
	public String saveDetails(User user){
		userDAO.saveOrUpdate(user);
		return "success";
		
	}
	
}

	
	

