package com.niit.Shoppingcart;


import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.Shopcart.dao.CategoryDAO;
import com.niit.Shopcart.dao.UserDAO;
import com.niit.Shopcart.model.Category;
import com.niit.Shopcart.model.User;

public class UserTest {
public static void main(String[] args) {
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		
		context.scan("com.niit.Shopcart");
		context.refresh();
		
		UserDAO userDAO = (UserDAO) context.getBean("userDAO");
		
		User user = (User) context.getBean("user");
		
	
		user.setUid("111");
		user.setUname("arv");
		user.setUpass("pass");
		user.setUemail("email.com");
		user.setUaddress("main road");
		
//		
		
//		

	userDAO.saveOrUpdate(user);
		
	}

}



