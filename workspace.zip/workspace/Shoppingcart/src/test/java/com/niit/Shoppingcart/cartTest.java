package com.niit.Shoppingcart;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.Shopcart.dao.CartDAO;
import com.niit.Shopcart.model.Cart;

public class cartTest {

	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		
		context.scan("com.niit.Shopcart");
		context.refresh();
		
		CartDAO cartDAO = (CartDAO) context.getBean("cartDAO");
		
		Cart cart = (Cart) context.getBean("cart");
		
	
		cart.setId(223);
		cart.setProductName("samsunggalexy");
		cart.setPrice(100);
		cart.setQuantity(111);
		cart.setStatus('n');
		
//		
		 //cartDAO.delete("232");
//		

cartDAO.saveOrUpdate(cart);
		
	}

}

	

