package com.niit.Shoppingcart;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.Shopcart.dao.CategoryDAO;
import com.niit.Shopcart.model.Category;

public class CategoryTest {
	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		
		context.scan("com.niit.Shopcart");
		context.refresh();
		
		CategoryDAO categoryDAO = (CategoryDAO) context.getBean("categoryDAO");
		
		Category category = (Category) context.getBean("category");
		
	
		category.setCat_id("223");
		category.setCat_name("samsunggalexy");
		category.setCat_des("best");
		
//		
		 //categoryDAO.delete("232");
//		

categoryDAO.saveOrUpdate(category);
		
	}

}


