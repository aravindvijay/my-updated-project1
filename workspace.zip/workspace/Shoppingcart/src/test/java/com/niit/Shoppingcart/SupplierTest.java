package com.niit.Shoppingcart;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.Shopcart.dao.SupplierDAO;
import com.niit.Shopcart.model.Supplier;

public class SupplierTest {
	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		
		context.scan("com.niit.Shopcart");
		context.refresh();
		
		SupplierDAO supplierDAO = (SupplierDAO) context.getBean("supplierDAO");
		
		Supplier supplier = (Supplier) context.getBean("supplier");
		
	
		supplier.setId("123");
		supplier.setName("sony");
		supplier.setAddress("desgh");
		
		supplierDAO.saveOrUpdate(supplier);
	}

}


