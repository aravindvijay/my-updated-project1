package com.niit.Shopcart.dao;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.Shopcart.model.Category;

@Repository("categoryDAO")
public class CategoryDAOImpl implements CategoryDAO {
	private static final Logger logger = 
			LoggerFactory.getLogger(CategoryDAOImpl.class);

	
	@Autowired
	private SessionFactory sessionFactory;
	public CategoryDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	@Transactional
	public List<Category> list() {
		logger.debug("callingList");
		@SuppressWarnings("unchecked")
		List<Category> listCategory = (List<Category>)
		        sessionFactory.getCurrentSession()
				.createCriteria(Category.class)
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
		logger.debug("calling end of List");
				return listCategory;
		
	}
    @Transactional
	public Category get(String Cat_id) {
		String hq1 = "from Category when cat_id="+"'"+Cat_id+"'";
		Query query = (Query) sessionFactory.getCurrentSession().createQuery(hq1);
		List<Category> listCategory = (List<Category>) query.getResultList();
		logger.debug("end of get");
	if (listCategory != null && !listCategory.isEmpty())
	{return listCategory.get(0);}	
	return null;
	}
   @Transactional
   public void saveOrUpdate(Category category) {
	   sessionFactory.getCurrentSession().saveOrUpdate(category);
		
	}
   
  
		@Transactional
		public void delete(String cat_id) {
			Category CategoryToDelete = new Category();
			CategoryToDelete.setCat_id(cat_id);
			sessionFactory.getCurrentSession().delete(CategoryToDelete);
		}

//		public Category getByName(String name) {
//			// TODO Auto-generated method stub
//			return null;
//		}

		@Transactional
	public Category getByName(String name) {
			logger.debug("calling getbyname");
			String hql = "from Category where name=" + "'"+ name +"'";
			Query query = sessionFactory.getCurrentSession().createQuery(hql);
			
			@SuppressWarnings("unchecked")
			List<Category> listCategory = (List<Category>) query.getResultList();
			logger.debug("end of getbyname");
			if (listCategory != null && !listCategory.isEmpty()) {
				return listCategory.get(0);
			}
			
			return null;
		}
		
	
}
