package com.niit.Shopcart.dao;

import java.util.List;

import com.niit.Shopcart.model.User;

public interface UserDAO {

	public List<User> list ();
	public User get (String uid);
	public void saveOrUpdate(User user);
	public void delete (String uname);
	public boolean isValiduser(String uname,String upass);
}
