package com.niit.Shopcart.dao;

import java.util.List;

import com.niit.Shopcart.model.Product;

public interface ProductDAO {

	public Product get(int id);
	public void saveOrUpdate(Product product);
	public void delete(String id);
	public Product getByName(String name);
	public List<Product> list();
}
