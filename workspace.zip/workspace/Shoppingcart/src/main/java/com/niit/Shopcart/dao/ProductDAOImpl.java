package com.niit.Shopcart.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.Shopcart.model.Product;

@Repository("productDAO")
public class ProductDAOImpl implements ProductDAO {

	
	@Autowired
	private SessionFactory sessionFactory;
	public ProductDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	@Transactional
	public List<Product> list() {
		
		@SuppressWarnings("unchecked")
		List<Product> listProduct = (List<Product>)
		        sessionFactory.getCurrentSession()
				.createCriteria(Product.class)
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
				return listProduct;
		
	}
	
    @Transactional
	public Product get(int id) {
		String hq1 = "from Product where id="+"'"+id +"'";
		Query query = (Query) sessionFactory.getCurrentSession().createQuery(hq1);
		List<Product> listProduct = (List<Product>) query.getResultList();
	if (listProduct != null && !listProduct.isEmpty())
	{return listProduct.get(0);}	
	return null;
	}
    
   @Transactional
   public void saveOrUpdate(Product product) {
	   sessionFactory.getCurrentSession().saveOrUpdate(product);
		
	}
    @Transactional
	public void delete(String id) {
    	Product ProductToDelete = new Product();
    	ProductToDelete.setId(id);
	
		
	}

	public Product getByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}
}
