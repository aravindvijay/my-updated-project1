package com.niit.Shopcart.dao;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.Shopcart.model.User;

@Repository("userDAO")
public class UserDAOImpl implements UserDAO {

	
	@Autowired
	private SessionFactory sessionFactory;
	public UserDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	
	}

	
	@Transactional
	public List<User> list() {
		@SuppressWarnings("unchecked")
		List<User> listUser = (List<User>)
		        sessionFactory.getCurrentSession()
				.createCriteria(User.class)
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
				return listUser;
		
	}
    @Transactional
	public User get(String uid) {
		String hq1 = "from user where uid="+"'"+uid+"'";
		Query query = (Query) sessionFactory.getCurrentSession().createQuery(hq1);
		List<User> listUser = (List<User>) query.getResultList();
	if (listUser != null && !listUser.isEmpty())
	{return listUser.get(0);}	
	return null;
	}
   @Transactional
   public void saveOrUpdate(User user) {
	   sessionFactory.getCurrentSession().saveOrUpdate(user);
		
	}
   
  
		@Transactional
		public void delete(String uid) {
			User UserToDelete = new User();
			UserToDelete.setUid(uid);
			sessionFactory.getCurrentSession().delete(UserToDelete);
		}
		
		  @Transactional
			public boolean isValiduser(String uname, String upass) {
				
				
		String hql = "from Users where uname= '"+uname+"' and "+" upass = '"+upass+"' ";
						Query query = (Query) sessionFactory.getCurrentSession().createQuery(hql);
						@SuppressWarnings("unchecked")
						List<User> list = (List<User>)  query.getResultList();
						if(list != null && !list.isEmpty())
						{
							System.out.println("done");
						return true;
						}
						else
						{
							System.out.println("no");
							return false;
						}
					}



			}
			

			



		

