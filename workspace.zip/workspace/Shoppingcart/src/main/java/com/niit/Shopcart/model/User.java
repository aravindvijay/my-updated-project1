package com.niit.Shopcart.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import org.springframework.stereotype.Component;



	@Entity

	@Component
	public class User implements Serializable
	{

		
		
		@Id
		private String uid;
		private String uname;
		private String upass;
		private String uph;
		private String uemail;
		private String uaddress;
		public String getUid() {
			return uid;
			
		
			
		}
		public void setUid(String uid) {
			this.uid = uid;
		}
		public String getUname() {
			return uname;
		}
		public void setUname(String uname) {
			this.uname = uname;
		}
		public String getUpass() {
			return upass;
		}
		public void setUpass(String upass) {
			this.upass = upass;
		}
		public String getUph() {
			return uph;
		}
		public void setUph(String uph) {
			this.uph = uph;
		}
		public String getUemail() {
			return uemail;
		}
		public void setUemail(String uemail) {
			this.uemail = uemail;
		}
		public String getUaddress() {
			return uaddress;
		}
		public void setUaddress(String uaddress) {
			this.uaddress = uaddress;
		}
		
		
		}
	
	
